<?php

// ============================================
// STRING HELPERS
// ============================================

function escape($string)
{
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function generateEmployeeNumber($role)
{
    $prefixes = [
        'owner' => 'SA',
        'hr_head' => 'HH',
        'hr_staff' => 'HS',
        'cashier' => 'CA',
        'finance_head' => 'FH',
        'finance_staff' => 'FS',
        'trainee' => 'TR'
    ];

    $prefix = $prefixes[$role] ?? 'USR';
    $random = str_pad(rand(100, 999), 3, '0', STR_PAD_LEFT);

    return $prefix . '-' . $random;
}

function generateDefaultPassword($firstName, $lastName)
{
    $password = $firstName . $lastName;
    if (strlen($password) < 8) {
        $password .= '1234';
    }
    return $password;
}

function getFullName($firstName, $lastName, $middleName = null)
{
    if ($middleName) {
        return $firstName . ' ' . $middleName . ' ' . $lastName;
    }
    return $firstName . ' ' . $lastName;
}

// ============================================
// DATE HELPERS
// ============================================

function formatDate($date, $format = 'F j, Y')
{
    return date($format, strtotime($date));
}

function formatTime($time, $format = 'h:i A')
{
    return date($format, strtotime($time));
}

function getCurrentDate()
{
    return date('Y-m-d');
}

function getCurrentDateTime()
{
    return date('Y-m-d H:i:s');
}

// ============================================
// FILE HELPERS
// ============================================

function uploadFile($file, $targetDir, $allowedTypes = [], $maxSize = 5242880)
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }

    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => 'File size exceeds limit'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!empty($allowedTypes) && !in_array($ext, $allowedTypes)) {
        return ['success' => false, 'message' => 'File type not allowed'];
    }

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
    $path = $targetDir . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $path)) {
        return ['success' => true, 'path' => $path, 'filename' => $filename];
    }

    return ['success' => false, 'message' => 'Failed to upload file'];
}

// ============================================
// NOTIFICATION HELPERS
// ============================================

function createNotification($userId, $type, $message, $link = null)
{
    $db = \App\Core\Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, type, message, link) 
        VALUES (?, ?, ?, ?)
    ");

    return $stmt->execute([$userId, $type, $message, $link]);
}

function getUnreadNotifications($userId)
{
    $db = \App\Core\Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? AND is_read = 0 
        ORDER BY created_at DESC
    ");

    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function getNotifications($userId, $limit = 10)
{
    $db = \App\Core\Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT ?
    ");

    $stmt->execute([$userId, $limit]);
    return $stmt->fetchAll();
}

function markNotificationAsRead($notificationId)
{
    $db = \App\Core\Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        UPDATE notifications SET is_read = 1 
        WHERE id = ?
    ");

    return $stmt->execute([$notificationId]);
}

function markAllNotificationsRead($userId)
{
    $db = \App\Core\Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        UPDATE notifications SET is_read = 1 
        WHERE user_id = ? AND is_read = 0
    ");

    return $stmt->execute([$userId]);
}

// ============================================
// ROLE HELPERS
// ============================================

function getRoleName($role)
{
    $roles = [
        'owner' => 'Owner',
        'hr_head' => 'HR Head',
        'hr_staff' => 'HR Staff',
        'cashier' => 'Cashier',
        'finance_head' => 'Finance Head',
        'finance_staff' => 'Finance Staff',
        'trainee' => 'Trainee'
    ];

    return $roles[$role] ?? ucfirst($role);
}

function getRoleBadgeClass($role)
{
    $classes = [
        'owner' => 'bg-danger',
        'hr_head' => 'bg-primary',
        'hr_staff' => 'bg-info text-dark',
        'cashier' => 'bg-success',
        'finance_head' => 'bg-warning text-dark',
        'finance_staff' => 'bg-secondary',
        'trainee' => 'bg-warning text-dark'
    ];

    return $classes[$role] ?? 'bg-secondary';
}

function getRoleIcon($role)
{
    $icons = [
        'owner' => 'bi-star-fill',
        'hr_head' => 'bi-people-fill',
        'hr_staff' => 'bi-person-fill',
        'cashier' => 'bi-cash',
        'finance_head' => 'bi-graph-up-arrow',
        'finance_staff' => 'bi-calculator',
        'trainee' => 'bi-mortarboard-fill'
    ];

    return $icons[$role] ?? 'bi-person';
}

// ============================================
// INTERVIEW HELPERS
// ============================================

function getInterviewStatusColor($status)
{
    $colors = [
        'scheduled' => 'warning',
        'completed' => 'info',
        'cancelled' => 'secondary',
        'passed' => 'success',
        'failed' => 'danger',
        'pending' => 'warning'
    ];

    return $colors[$status] ?? 'secondary';
}

function getInterviewResultText($result)
{
    $texts = [
        'passed' => '✅ Passed',
        'failed' => '❌ Failed',
        'pending' => '⏳ Pending'
    ];

    return $texts[$result] ?? '—';
}

// ============================================
// APPLICANT STATUS HELPERS
// ============================================

function getApplicantStatusColor($status)
{
    $colors = [
        'pending' => 'warning',
        'initial_scheduled' => 'info',
        'initial_passed' => 'primary',
        'initial_failed' => 'danger',
        'final_scheduled' => 'info',
        'final_passed' => 'primary',
        'final_failed' => 'danger',
        'screening' => 'success',
        'contract_offered' => 'warning',
        'contract_accepted' => 'success',
        'contract_declined' => 'danger',
        'hired' => 'success'
    ];

    return $colors[$status] ?? 'secondary';
}

function getApplicantStatusText($status)
{
    $texts = [
        'pending' => 'Pending Review',
        'initial_scheduled' => 'Initial Interview Scheduled',
        'initial_passed' => 'Passed Initial Interview',
        'initial_failed' => 'Failed Initial Interview',
        'final_scheduled' => 'Final Interview Scheduled',
        'final_passed' => 'Passed Final Interview',
        'final_failed' => 'Failed Final Interview',
        'screening' => 'In Training/Screening',
        'contract_offered' => 'Contract Offered',
        'contract_accepted' => 'Contract Accepted',
        'contract_declined' => 'Contract Declined',
        'hired' => 'Hired'
    ];

    return $texts[$status] ?? ucfirst(str_replace('_', ' ', $status));
}

// ============================================
// LEAVE HELPERS - NEW
// ============================================

function getLeaveTypeText($type)
{
    $types = [
        'sick' => 'Sick Leave (Paid)',
        'vacation' => 'Vacation Leave (Paid)',
        'emergency' => 'Emergency Leave (Paid)',
        'other' => 'Other (Unpaid)'
    ];

    return $types[$type] ?? ucfirst($type);
}

function getLeaveStatusColor($status)
{
    $colors = [
        'pending' => 'warning',
        'approved' => 'success',
        'rejected' => 'danger'
    ];

    return $colors[$status] ?? 'secondary';
}

function getLeaveStatusText($status)
{
    $texts = [
        'pending' => '⏳ Pending',
        'approved' => '✅ Approved',
        'rejected' => '❌ Rejected'
    ];

    return $texts[$status] ?? $status;
}

function getLeaveIsPaidText($isPaid)
{
    return $isPaid ? '✅ Paid' : '❌ Unpaid';
}

function getLeaveIsPaidBadge($isPaid)
{
    return $isPaid 
        ? '<span class="badge bg-success">✅ Paid</span>'
        : '<span class="badge bg-secondary">❌ Unpaid</span>';
}

// ============================================
// LEAVE BALANCE HELPERS
// ============================================

function getLeaveBalanceForYear($userId, $year = null)
{
    if ($year === null) {
        $year = date('Y');
    }
    
    $db = \App\Core\Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("
        SELECT * FROM leave_balances 
        WHERE user_id = ? AND year = ?
    ");
    $stmt->execute([$userId, $year]);
    $balance = $stmt->fetch();
    
    if (!$balance) {
        // Create default balance if not exists
        $stmt = $db->prepare("
            INSERT INTO leave_balances (user_id, year) 
            VALUES (?, ?)
        ");
        $stmt->execute([$userId, $year]);
        
        return [
            'sick_leave_entitled' => 15,
            'sick_leave_used' => 0,
            'vacation_leave_entitled' => 15,
            'vacation_leave_used' => 0,
            'emergency_leave_entitled' => 5,
            'emergency_leave_used' => 0,
            'other_leave_entitled' => 0,
            'other_leave_used' => 0
        ];
    }
    
    return $balance;
}

function getLeaveSummary($userId)
{
    $balance = getLeaveBalanceForYear($userId);
    
    return [
        'sick' => [
            'entitled' => $balance['sick_leave_entitled'],
            'used' => $balance['sick_leave_used'],
            'remaining' => $balance['sick_leave_entitled'] - $balance['sick_leave_used'],
            'is_paid' => true
        ],
        'vacation' => [
            'entitled' => $balance['vacation_leave_entitled'],
            'used' => $balance['vacation_leave_used'],
            'remaining' => $balance['vacation_leave_entitled'] - $balance['vacation_leave_used'],
            'is_paid' => true
        ],
        'emergency' => [
            'entitled' => $balance['emergency_leave_entitled'],
            'used' => $balance['emergency_leave_used'],
            'remaining' => $balance['emergency_leave_entitled'] - $balance['emergency_leave_used'],
            'is_paid' => true
        ],
        'other' => [
            'entitled' => $balance['other_leave_entitled'] ?? 0,
            'used' => $balance['other_leave_used'] ?? 0,
            'remaining' => 0,
            'is_paid' => false
        ]
    ];
}

function getWorkingDays($startDate, $endDate)
{
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $end->modify('+1 day');
    
    $interval = new DateInterval('P1D');
    $period = new DatePeriod($start, $interval, $end);
    
    $workingDays = 0;
    foreach ($period as $date) {
        $dayOfWeek = $date->format('N');
        if ($dayOfWeek < 6) {
            $workingDays++;
        }
    }
    
    return $workingDays;
}

function getLeaveDuration($startDate, $endDate)
{
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $diff = $start->diff($end);
    return $diff->days + 1;
}

function checkLeaveOverlap($userId, $startDate, $endDate, $excludeId = null)
{
    $db = \App\Core\Database::getInstance()->getConnection();
    
    $sql = "
        SELECT COUNT(*) as count 
        FROM leaves 
        WHERE user_id = ? 
            AND status != 'rejected'
            AND (
                (start_date <= ? AND end_date >= ?) OR
                (start_date <= ? AND end_date >= ?) OR
                (start_date >= ? AND end_date <= ?)
            )
    ";
    
    $params = [$userId, $endDate, $startDate, $startDate, $startDate, $startDate, $endDate];
    
    if ($excludeId) {
        $sql .= " AND id != ?";
        $params[] = $excludeId;
    }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetch()['count'] > 0;
}

// ============================================
// TRAINER STATUS HELPERS
// ============================================

function getTrainerStatus($userId)
{
    $db = \App\Core\Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("SELECT can_train FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if (!$user) {
        return ['status' => 'unknown', 'label' => 'Unknown'];
    }
    
    if ($user['can_train'] == 1) {
        return ['status' => 'available', 'label' => '🟢 Available to Train'];
    }
    
    $stmt = $db->prepare("
        SELECT COUNT(*) as count, id, applicant_id 
        FROM trainees 
        WHERE trainer_id = ? AND status = 'active'
    ");
    $stmt->execute([$userId]);
    $training = $stmt->fetch();
    
    if ($training && $training['count'] > 0) {
        return [
            'status' => 'locked', 
            'label' => '🔒 Currently Training',
            'trainee_id' => $training['id']
        ];
    }
    
    return ['status' => 'locked', 'label' => '🔒 Unavailable'];
}

// ============================================
// SHIFT HELPERS
// ============================================

function getShiftLabel($shift)
{
    $shifts = [
        'opening' => 'Opening (6:00 AM - 2:00 PM)',
        'closing' => 'Closing (2:00 PM - 10:00 PM)',
        'midshift' => 'MidShift (10:00 AM - 6:00 PM)'
    ];

    return $shifts[$shift] ?? ucfirst($shift);
}

function getShiftTime($shift)
{
    $times = [
        'opening' => ['06:00', '14:00'],
        'closing' => ['14:00', '22:00'],
        'midshift' => ['10:00', '18:00']
    ];

    return $times[$shift] ?? ['00:00', '00:00'];
}

// ============================================
// PAGINATION HELPER
// ============================================

function renderPagination($currentPage, $totalPages, $baseUrl, $queryParams = [])
{
    if ($totalPages <= 1) {
        return '';
    }

    $html = '<nav><ul class="pagination pagination-sm justify-content-center">';

    if ($currentPage > 1) {
        $params = array_merge($queryParams, ['page' => $currentPage - 1]);
        $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . http_build_query($params) . '">«</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">«</span></li>';
    }

    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);

    if ($start > 1) {
        $params = array_merge($queryParams, ['page' => 1]);
        $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . http_build_query($params) . '">1</a></li>';
        if ($start > 2) {
            $html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }

    for ($i = $start; $i <= $end; $i++) {
        if ($i === $currentPage) {
            $html .= '<li class="page-item active"><span class="page-link">' . $i . '</span></li>';
        } else {
            $params = array_merge($queryParams, ['page' => $i]);
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . http_build_query($params) . '">' . $i . '</a></li>';
        }
    }

    if ($end < $totalPages) {
        if ($end < $totalPages - 1) {
            $html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        $params = array_merge($queryParams, ['page' => $totalPages]);
        $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . http_build_query($params) . '">' . $totalPages . '</a></li>';
    }

    if ($currentPage < $totalPages) {
        $params = array_merge($queryParams, ['page' => $currentPage + 1]);
        $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . http_build_query($params) . '">»</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">»</span></li>';
    }

    $html .= '</ul></nav>';
    return $html;
}

// ============================================
// SESSION FLASH HELPERS
// ============================================

function setFlash($message, $type = 'info')
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

function getFlash()
{
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        return ['message' => $message, 'type' => $type];
    }
    return null;
}

// ============================================
// VALIDATION HELPERS
// ============================================

function validateEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone)
{
    return preg_match('/^[0-9]{10,12}$/', $phone);
}

function validateDate($date, $format = 'Y-m-d')
{
    $d = \DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

function validateFileType($filename, $allowedTypes)
{
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowedTypes);
}