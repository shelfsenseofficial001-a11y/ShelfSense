<?php
// app/handlers/hr/create_trainee_with_trainer.php

require_once __DIR__ . '/../../core/Database.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;

header('Content-Type: application/json');

// Check authentication
if (!Auth::check()) {
    Response::unauthorized('Please login to access this resource');
}

// Check role
if (!Auth::isHR() && !Auth::isOwner()) {
    Response::forbidden('Access denied. HR role required.');
}

// Get input
$input = json_decode(file_get_contents('php://input'), true);
error_log('📥 create_trainee_with_trainer input: ' . print_r($input, true));

$applicantId = isset($input['applicant_id']) ? intval($input['applicant_id']) : 0;
$trainerId = isset($input['trainer_id']) ? intval($input['trainer_id']) : 0;
$salaryMin = isset($input['salary_min']) ? floatval($input['salary_min']) : 3900;
$salaryMax = isset($input['salary_max']) ? floatval($input['salary_max']) : 4500;

// Validate required fields
if ($applicantId <= 0) {
    error_log('❌ Invalid applicant_id: ' . $applicantId);
    Response::error('Invalid applicant ID.', 400);
}

if ($trainerId <= 0) {
    error_log('❌ Invalid trainer_id: ' . $trainerId);
    Response::error('Please select a valid trainer.', 400);
}

// Validate salary range
if ($salaryMin < 3900) $salaryMin = 3900;
if ($salaryMax > 4500) $salaryMax = 4500;
if ($salaryMin > $salaryMax) {
    $salaryMin = 3900;
    $salaryMax = 4500;
}

try {
    $db = Database::getInstance()->getConnection();

    // Get applicant details (must be final_passed)
    $stmt = $db->prepare("SELECT * FROM applicants WHERE id = ?");
    $stmt->execute([$applicantId]);
    $applicant = $stmt->fetch();

    if (!$applicant) {
        error_log('❌ Applicant not found: ' . $applicantId);
        Response::error('Applicant not found.', 404);
    }

    // Check status
    if ($applicant['status'] !== 'final_passed') {
        error_log('❌ Applicant status not final_passed: ' . $applicant['status']);
        Response::error('Applicant must have passed the final interview (status: final_passed). Current status: ' . $applicant['status'], 400);
    }

    // ✅ ROLE MAPPING - Convert display name to database role
    $roleMap = [
        'Cashier' => 'cashier',
        'HR Staff' => 'hr_staff',
        'Finance Staff' => 'finance_staff',
        'Head HR' => 'hr_head',
        'Head Finance' => 'finance_head'
    ];
    $dbTargetRole = $roleMap[$applicant['target_role']] ?? $applicant['target_role'];
    error_log('🔍 Target role: ' . $applicant['target_role'] . ' → DB role: ' . $dbTargetRole);

    // ✅ Select trainer with can_train = 1
    $stmt = $db->prepare("SELECT user_id, role, can_train, first_name, last_name FROM users WHERE user_id = ? AND is_active = 1");
    $stmt->execute([$trainerId]);
    $trainer = $stmt->fetch();

    if (!$trainer) {
        error_log('❌ Trainer not found or inactive: ' . $trainerId);
        Response::error('Trainer not found or inactive.', 400);
    }

    if ($trainer['can_train'] != 1) {
        error_log('❌ Trainer cannot_train: ' . $trainerId . ' (can_train=' . $trainer['can_train'] . ')');
        Response::error('This trainer is currently locked. Please select another trainer.', 400);
    }

    // ✅ Role comparison using mapped role
    if (strtolower($trainer['role']) !== strtolower($dbTargetRole)) {
        error_log('❌ Role mismatch: trainer=' . $trainer['role'] . ', target=' . $dbTargetRole);
        Response::error(
            'Trainer must have the same role as the trainee\'s target role. Selected trainer is: ' . $trainer['role'] . ', target role is: ' . $applicant['target_role'],
            400
        );
    }

    // ✅ Lock trainer if not exempt
    $shouldLockTrainer = true;
    $exemptRoles = ['hr_head', 'owner', 'manager'];
    if (in_array(strtolower($trainer['role']), $exemptRoles)) {
        $shouldLockTrainer = false;
        error_log('✅ Trainer exempt from locking: ' . $trainer['role']);
    }

    if ($shouldLockTrainer) {
        // Check if trainer already has an active trainee
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM trainees WHERE trainer_id = ? AND status = 'active'");
        $stmt->execute([$trainerId]);
        $activeCount = $stmt->fetch()['count'];
        if ($activeCount > 0) {
            error_log('❌ Trainer already has active trainee: ' . $trainerId);
            Response::error('This trainer is already training someone. Please select another trainer.', 400);
        }

        // Lock the trainer
        $stmt = $db->prepare("UPDATE users SET can_train = 0, updated_at = NOW() WHERE user_id = ?");
        $stmt->execute([$trainerId]);
        error_log('🔒 Trainer locked: ' . $trainerId);
    }

    // Check if user already exists for this applicant
    $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$applicant['email']]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
        $newUserId = $existingUser['user_id'];
        error_log('⚠️ User already exists for email: ' . $applicant['email'] . ', using existing user_id: ' . $newUserId);
        $defaultPassword = null;
    } else {
        $employeeNumber = generateEmployeeNumber('trainee');
        $defaultPassword = generateDefaultPassword($applicant['first_name'], $applicant['last_name']);
        $hashedPassword = password_hash($defaultPassword, PASSWORD_DEFAULT);

        $stmt = $db->prepare("
            INSERT INTO users (employee_number, first_name, last_name, middle_name, email, password, role, is_first_login, can_train) 
            VALUES (?, ?, ?, ?, ?, ?, 'trainee', 1, 0)
        ");
        $stmt->execute([
            $employeeNumber,
            $applicant['first_name'],
            $applicant['last_name'],
            $applicant['middle_name'] ?? '',
            $applicant['email'],
            $hashedPassword
        ]);
        $newUserId = $db->lastInsertId();
        error_log('✅ New user created with ID: ' . $newUserId);
    }

    // Get employee number for the new user
    $stmt = $db->prepare("SELECT employee_number FROM users WHERE user_id = ?");
    $stmt->execute([$newUserId]);
    $empData = $stmt->fetch();
    $employeeNumber = $empData ? $empData['employee_number'] : '';

    // Check if trainee record already exists
    $stmt = $db->prepare("SELECT id FROM trainees WHERE applicant_id = ?");
    $stmt->execute([$applicantId]);
    $existingTrainee = $stmt->fetch();

    $startDate = date('Y-m-d');
    $endDate = date('Y-m-d', strtotime('+3 months'));
    $scheduleStart = '10:00:00';
    $scheduleEnd = '15:00:00';

    if ($existingTrainee) {
        $stmt = $db->prepare("
            UPDATE trainees 
            SET user_id = ?, trainer_id = ?, target_role = ?, start_date = ?, end_date = ?, 
                schedule_start = ?, schedule_end = ?, status = 'active',
                trainee_salary_min = ?, trainee_salary_max = ?,
                updated_at = NOW()
            WHERE applicant_id = ?
        ");
        $stmt->execute([
            $newUserId,
            $trainerId,
            $applicant['target_role'],
            $startDate,
            $endDate,
            $scheduleStart,
            $scheduleEnd,
            $salaryMin,
            $salaryMax,
            $applicantId
        ]);
        $traineeId = $existingTrainee['id'];
    } else {
        $stmt = $db->prepare("
            INSERT INTO trainees (applicant_id, user_id, trainer_id, target_role, start_date, end_date, schedule_start, schedule_end, status, trainee_salary_min, trainee_salary_max) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
        ");
        $stmt->execute([
            $applicantId,
            $newUserId,
            $trainerId,
            $applicant['target_role'],
            $startDate,
            $endDate,
            $scheduleStart,
            $scheduleEnd,
            $salaryMin,
            $salaryMax
        ]);
        $traineeId = $db->lastInsertId();
    }

    // Update applicant status
    $stmt = $db->prepare("UPDATE applicants SET status = 'screening', updated_at = NOW() WHERE id = ?");
    $stmt->execute([$applicantId]);

    // Create notification
    $lockStatus = $shouldLockTrainer ? 'locked' : 'NOT locked (exempt role)';
    $notificationMessage = "Trainee account created for {$applicant['first_name']} {$applicant['last_name']}. Trainer {$trainer['first_name']} {$trainer['last_name']} is {$lockStatus}.";
    createNotification(Auth::userId(), 'trainee_created', $notificationMessage);

    // Build trainer name safely
    $trainerName = trim(($trainer['first_name'] ?? '') . ' ' . ($trainer['last_name'] ?? ''));
    if (empty($trainerName)) {
        $trainerName = 'Trainer #' . $trainerId;
    }

    Response::success([
        'trainee_id' => $traineeId,
        'user_id' => $newUserId,
        'employee_number' => $employeeNumber,
        'default_password' => $defaultPassword,
        'salary_min' => $salaryMin,
        'salary_max' => $salaryMax,
        'trainer_id' => $trainerId,
        'trainer_name' => $trainerName,
        'trainer_locked' => $shouldLockTrainer,
        'trainer_role' => $trainer['role']
    ], 'Trainee account created successfully.');

} catch (Exception $e) {
    error_log('❌ create_trainee_with_trainer.php error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    Response::error('Error: ' . $e->getMessage());
}