<?php
// app/handlers/hr/get_contracts.php

require_once __DIR__ . '/../../core/Database.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;

header('Content-Type: application/json');

if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!Auth::isHR() && !Auth::isOwner()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Get parameters
    $page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
    $limit = isset($_GET['limit']) ? min(50, max(1, intval($_GET['limit']))) : 15;
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    // Build WHERE clause
    $where = "1=1";
    $params = [];

    if ($status !== 'all') {
        $where .= " AND c.status = ?";
        $params[] = $status;
    }

    if (!empty($search)) {
        $where .= " AND (a.first_name LIKE ? OR a.last_name LIKE ? OR a.email LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }

    if (strlen($search) > 100) {
        Response::error('Search term cannot exceed 100 characters.', 400);
    }

    // Get total count
    $countSql = "SELECT COUNT(*) as total FROM contracts c 
                 JOIN applicants a ON c.applicant_id = a.id 
                 WHERE $where";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetch()['total'];

    // Get data with joins
    $offset = ($page - 1) * $limit;
    $sql = "SELECT 
                c.*,
                a.first_name as applicant_first_name,
                a.last_name as applicant_last_name,
                a.email as applicant_email,
                a.target_role,
                u.first_name as trainee_first_name,
                u.last_name as trainee_last_name,
                u.employee_number
            FROM contracts c
            JOIN applicants a ON c.applicant_id = a.id
            JOIN users u ON c.user_id = u.user_id
            WHERE $where
            ORDER BY c.created_at DESC
            LIMIT ? OFFSET ?";
    
    $stmt = $db->prepare($sql);
    $queryParams = array_merge($params, [$limit, $offset]);
    $stmt->execute($queryParams);
    $contracts = $stmt->fetchAll();

    // Format data
    $shiftLabels = [
        'opening' => 'Opening (6am-2pm)',
        'closing' => 'Closing (2pm-10pm)',
        'midshift' => 'MidShift (10am-6pm)'
    ];

    $statusColors = [
        'pending' => 'warning',
        'accepted' => 'success',
        'declined' => 'danger'
    ];

    foreach ($contracts as &$contract) {
        $contract['applicant_name'] = $contract['applicant_first_name'] . ' ' . $contract['applicant_last_name'];
        $contract['trainee_name'] = $contract['trainee_first_name'] . ' ' . $contract['trainee_last_name'];
        $contract['shift_label'] = $shiftLabels[$contract['shift']] ?? ucfirst($contract['shift']);
        $contract['status_color'] = $statusColors[$contract['status']] ?? 'secondary';
        $contract['formatted_start'] = date('M d, Y', strtotime($contract['start_date']));
        $contract['formatted_salary'] = '₱' . number_format($contract['salary'], 2);
    }

    // Stats
    $statsSql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
                    SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END) as declined
                 FROM contracts";
    $statsStmt = $db->query($statsSql);
    $stats = $statsStmt->fetch();

    echo json_encode([
        'success' => true,
        'data' => [
            'contracts' => $contracts,
            'pagination' => [
                'currentPage' => $page,
                'perPage' => $limit,
                'totalRecords' => (int)$total,
                'totalPages' => ceil($total / $limit)
            ],
            'stats' => [
                'total' => (int)($stats['total'] ?? 0),
                'pending' => (int)($stats['pending'] ?? 0),
                'accepted' => (int)($stats['accepted'] ?? 0),
                'declined' => (int)($stats['declined'] ?? 0)
            ],
            'filters' => ['status' => $status, 'search' => $search]
        ],
        'message' => 'Contracts fetched successfully'
    ]);

} catch (Exception $e) {
    error_log('get_contracts.php error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}