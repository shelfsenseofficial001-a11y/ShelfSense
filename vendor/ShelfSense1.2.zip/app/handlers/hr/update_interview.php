<?php
// app/handlers/hr/update_interview.php

require_once __DIR__ . '/../../core/Database.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;

header('Content-Type: application/json');

if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!Auth::isHR() && !Auth::isOwner()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$interviewId = isset($input['interview_id']) ? intval($input['interview_id']) : 0;
$action = isset($input['action']) ? trim($input['action']) : '';
$result = isset($input['result']) ? trim($input['result']) : '';

if ($interviewId <= 0 || empty($action)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Get current interview data
    $stmt = $db->prepare("SELECT i.*, a.id as applicant_id, a.status as applicant_status 
                          FROM interviews i 
                          JOIN applicants a ON i.applicant_id = a.id 
                          WHERE i.id = ?");
    $stmt->execute([$interviewId]);
    $interview = $stmt->fetch();

    if (!$interview) {
        echo json_encode(['success' => false, 'message' => 'Interview not found']);
        exit;
    }

    $currentUserId = Auth::userId();

    switch ($action) {
        case 'complete':
            // Mark interview as completed (no result yet)
            $stmt = $db->prepare("UPDATE interviews SET status = 'completed', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$interviewId]);
            $message = 'Interview marked as completed';
            break;

        case 'cancel':
            // Cancel interview
            $stmt = $db->prepare("UPDATE interviews SET status = 'cancelled', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$interviewId]);
            $message = 'Interview cancelled';
            break;

        case 'set_result':
            // Set result (passed/failed)
            if (!in_array($result, ['passed', 'failed'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid result value']);
                exit;
            }

            $stmt = $db->prepare("UPDATE interviews SET status = 'completed', result = ?, notes = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$result, $input['notes'] ?? null, $interviewId]);
            
            // Update applicant status based on interview type and result
            $newStatus = '';
            if ($interview['interview_type'] === 'initial') {
                $newStatus = $result === 'passed' ? 'initial_passed' : 'initial_failed';
            } elseif ($interview['interview_type'] === 'final') {
                $newStatus = $result === 'passed' ? 'final_passed' : 'final_failed';
            }

            if (!empty($newStatus)) {
                $stmt = $db->prepare("UPDATE applicants SET status = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$newStatus, $interview['applicant_id']]);
            }

            $message = 'Interview result set to: ' . ucfirst($result);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit;
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'interview_id' => $interviewId,
            'action' => $action,
            'result' => $result ?? null
        ],
        'message' => $message
    ]);

} catch (Exception $e) {
    error_log('update_interview.php error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}