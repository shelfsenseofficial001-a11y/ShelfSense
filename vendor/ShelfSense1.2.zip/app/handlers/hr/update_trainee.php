<?php
// app/handlers/hr/update_trainee.php

require_once __DIR__ . '/../../core/Database.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;

header('Content-Type: application/json');

if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!Auth::isHR() && !Auth::isOwner()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$traineeId = isset($input['trainee_id']) ? intval($input['trainee_id']) : 0;
$action = isset($input['action']) ? trim($input['action']) : '';
$trainerId = isset($input['trainer_id']) ? intval($input['trainer_id']) : 0;

if ($traineeId <= 0 || empty($action)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Get current trainee data
    $stmt = $db->prepare("SELECT t.*, a.id as applicant_id, a.status as applicant_status 
                          FROM trainees t 
                          JOIN applicants a ON t.applicant_id = a.id 
                          WHERE t.id = ?");
    $stmt->execute([$traineeId]);
    $trainee = $stmt->fetch();

    if (!$trainee) {
        echo json_encode(['success' => false, 'message' => 'Trainee not found']);
        exit;
    }

    switch ($action) {
        case 'assign_trainer':
            // Assign a trainer to the trainee
            if ($trainerId <= 0) {
                echo json_encode(['success' => false, 'message' => 'Please select a trainer']);
                exit;
            }
            
            // Verify trainer exists and can train
            $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ? AND is_active = 1 AND can_train = 1");
            $stmt->execute([$trainerId]);
            $trainer = $stmt->fetch();
            
            if (!$trainer) {
                echo json_encode(['success' => false, 'message' => 'Invalid trainer selected']);
                exit;
            }
            
            $stmt = $db->prepare("UPDATE trainees SET trainer_id = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$trainerId, $traineeId]);
            $message = 'Trainer assigned successfully';
            break;

        case 'complete':
            // Mark training as completed
            $stmt = $db->prepare("UPDATE trainees SET status = 'completed', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$traineeId]);
            
            // Update applicant status
            $stmt = $db->prepare("UPDATE applicants SET status = 'screening_success', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$trainee['applicant_id']]);
            
            $message = 'Training marked as completed';
            break;

        case 'terminate':
            // Terminate the trainee
            $stmt = $db->prepare("UPDATE trainees SET status = 'terminated', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$traineeId]);
            
            // Update applicant status
            $stmt = $db->prepare("UPDATE applicants SET status = 'screening_failed', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$trainee['applicant_id']]);
            
            $message = 'Trainee terminated';
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit;
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'trainee_id' => $traineeId,
            'action' => $action
        ],
        'message' => $message
    ]);

} catch (Exception $e) {
    error_log('update_trainee.php error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}