<?php
// app/handlers/hr/get_applicants.php

require_once __DIR__ . '/../../models/Applicant.php';

use App\Core\Auth;
use App\Core\Response;
use App\Models\Applicant;

header('Content-Type: application/json');

if (!Auth::check()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!Auth::isHR() && !Auth::isOwner()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

try {
    // Get parameters
    $page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
    $limit = isset($_GET['limit']) ? min(50, max(1, intval($_GET['limit']))) : 15;
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $role = isset($_GET['role']) ? trim($_GET['role']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    // Build filters
    $filters = [
        'status' => $status,
        'search' => $search,
        'role' => $role
    ];

    // Get applicants using the model
    $applicantModel = new Applicant();
    $result = $applicantModel->getAll($page, $limit, $filters);

    // Add status display names
    $statusLabels = [
        'pending' => 'Pending Review',
        'initial_scheduled' => 'Initial Interview Scheduled',
        'initial_passed' => 'Passed Initial Interview',
        'initial_failed' => 'Failed Initial Interview',
        'final_scheduled' => 'Final Interview Scheduled',
        'final_passed' => 'Passed Final Interview',
        'final_failed' => 'Failed Final Interview',
        'screening' => 'In Training',
        'screening_success' => 'Training Completed',
        'screening_failed' => 'Training Failed',
        'contract_offered' => 'Contract Offered',
        'contract_declined' => 'Contract Declined',
        'hired' => 'Hired'
    ];

    foreach ($result['applicants'] as &$applicant) {
        $applicant['status_label'] = $statusLabels[$applicant['status']] ?? ucfirst($applicant['status']);
        $applicant['resume_url'] = '/ShelfSense/public/' . $applicant['resume_path'];
    }

    if (strlen($search) > 100) {
        Response::error('Search term cannot exceed 100 characters.', 400);
    }

    // Get stats
    $stats = $applicantModel->getStatusCounts();

    echo json_encode([
        'success' => true,
        'data' => [
            'applicants' => $result['applicants'],
            'pagination' => $result['pagination'],
            'stats' => $stats,
            'filters' => $filters
        ],
        'message' => 'Applicants fetched successfully'
    ]);
    exit;

} catch (Exception $e) {
    error_log('get_applicants.php error: ' . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
    exit;
}