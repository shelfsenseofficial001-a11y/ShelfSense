<?php
// app/handlers/hr/update_contract.php

require_once __DIR__ . '/../../core/Database.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Response;

header('Content-Type: application/json');

if (!Auth::check()) {
    Response::unauthorized('Please login to access this resource');
}

if (!Auth::isHR() && !Auth::isOwner()) {
    Response::forbidden('Access denied. HR role required.');
}

$input = json_decode(file_get_contents('php://input'), true);
$contractId = isset($input['contract_id']) ? intval($input['contract_id']) : 0;
$action = isset($input['action']) ? trim($input['action']) : '';

if ($contractId <= 0 || empty($action)) {
    Response::error('Missing required fields', 400);
}

try {
    $db = Database::getInstance()->getConnection();

    // Get contract details with applicant target role and user first name
    $stmt = $db->prepare("
        SELECT c.*, a.target_role, u.first_name, u.user_id as employee_user_id
        FROM contracts c 
        JOIN applicants a ON c.applicant_id = a.id 
        JOIN users u ON c.user_id = u.user_id 
        WHERE c.id = ?
    ");
    $stmt->execute([$contractId]);
    $contract = $stmt->fetch();

    if (!$contract) {
        Response::notFound('Contract not found');
    }

    if ($contract['status'] !== 'pending') {
        Response::error('This contract has already been processed.', 400);
    }

    switch ($action) {
        case 'accept':
            $targetRole = $contract['target_role'];
            $firstName = $contract['first_name'];
            $userId = $contract['employee_user_id'];

            // Map target role to database role
            $roleMap = [
                'Cashier' => 'cashier',
                'HR Staff' => 'hr_staff',
                'Finance Staff' => 'finance_staff',
                'Head HR' => 'hr_head',
                'Head Finance' => 'finance_head'
            ];
            $dbRole = $roleMap[$targetRole] ?? 'cashier';

            // Generate new employee number
            $rolePrefixes = [
                'Cashier' => 'CA',
                'HR Staff' => 'HS',
                'Finance Staff' => 'FS',
                'Head HR' => 'HH',
                'Head Finance' => 'FH'
            ];
            $prefix = $rolePrefixes[$targetRole] ?? 'USR';

            $unique = false;
            $attempts = 0;
            while (!$unique && $attempts < 10) {
                $number = str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
                $newEmployeeNumber = $prefix . '-' . $number;
                $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE employee_number = ?");
                $stmt->execute([$newEmployeeNumber]);
                if ($stmt->fetchColumn() == 0) {
                    $unique = true;
                }
                $attempts++;
            }
            if (!$unique) {
                $newEmployeeNumber = $prefix . '-' . substr(time(), -3);
            }

            // Update contract
            $stmt = $db->prepare("UPDATE contracts SET status = 'accepted', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$contractId]);

            // Update applicant
            $stmt = $db->prepare("UPDATE applicants SET status = 'hired', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$contract['applicant_id']]);

            // ✅ UPDATE USER: role, employee_number, can_train = 1, is_first_login = 1, hired_date = NOW()
            $stmt = $db->prepare("
                UPDATE users 
                SET role = ?, 
                    employee_number = ?, 
                    can_train = 1, 
                    is_first_login = 1, 
                    hired_date = NOW(),
                    updated_at = NOW() 
                WHERE user_id = ?
            ");
            $stmt->execute([$dbRole, $newEmployeeNumber, $userId]);

            // ✅ Ensure trainee record is marked as completed if not already
            $stmt = $db->prepare("
                UPDATE trainees 
                SET status = 'completed', 
                    training_completed_at = NOW(),
                    updated_at = NOW() 
                WHERE user_id = ? AND status != 'completed'
            ");
            $stmt->execute([$userId]);

            $message = 'Contract accepted. Employee hired! New employee can now train others.';
            break;

        case 'decline':
            $stmt = $db->prepare("UPDATE contracts SET status = 'declined', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$contractId]);

            $stmt = $db->prepare("UPDATE applicants SET status = 'contract_declined', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$contract['applicant_id']]);

            $message = 'Contract declined.';
            break;

        case 'update_details':
            $shift = isset($input['shift']) ? trim($input['shift']) : '';
            $salary = isset($input['salary']) ? floatval($input['salary']) : 0;
            $startDate = isset($input['start_date']) ? trim($input['start_date']) : '';
            $jobDetails = isset($input['job_details']) ? trim($input['job_details']) : '';
            $decisionDeadline = isset($input['decision_deadline']) ? trim($input['decision_deadline']) : '';

            if (empty($shift) || $salary <= 0 || empty($startDate) || empty($decisionDeadline)) {
                Response::error('All required fields must be filled.', 400);
            }

            $stmt = $db->prepare("
                UPDATE contracts 
                SET shift = ?, salary = ?, start_date = ?, 
                    job_details = ?, decision_deadline = ?, 
                    updated_at = NOW() 
                WHERE id = ? AND status = 'pending'
            ");
            $stmt->execute([$shift, $salary, $startDate, $jobDetails, $decisionDeadline, $contractId]);

            if ($stmt->rowCount() === 0) {
                Response::error('Contract not found or already processed.', 404);
            }

            if (strlen($jobDetails) > 250) {
                Response::error('Job details cannot exceed 250 characters.', 400);
            }

            $message = 'Contract details updated successfully.';
            break;

        default:
            Response::error('Invalid action');
    }

    // Create notification
    $notificationMessage = "Contract {$action}ed for employee ID: " . $contract['employee_user_id'];
    createNotification(Auth::userId(), 'contract_' . $action, $notificationMessage);

    Response::success([
        'contract_id' => $contractId,
        'action' => $action,
        'employee_can_train' => ($action === 'accept') // ✅ New employee can train
    ], $message);

} catch (Exception $e) {
    error_log('update_contract.php error: ' . $e->getMessage());
    Response::error('Error: ' . $e->getMessage());
}