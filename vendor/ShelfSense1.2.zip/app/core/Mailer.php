<?php
namespace App\Core;

class Mailer
{
    public function __construct() {}

    public function send($to, $subject, $body, $attachments = [])
    {
        error_log("📧 [DISABLED] To: $to, Subject: $subject");
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendApplicationReceived($applicant, $role)
    {
        error_log("📧 [DISABLED] Application received: " . ($applicant['email'] ?? 'unknown'));
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendInterviewScheduled($applicant, $interview)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendRejection($applicant, $stage, $reason = null)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendPassed($applicant, $stage)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendTraineeCreated($applicant, $trainee)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendLeaveApproved($user, $leave)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }

    public function sendLeaveRejected($user, $leave, $reason = null)
    {
        return ['success' => true, 'message' => 'Email disabled for testing'];
    }
}