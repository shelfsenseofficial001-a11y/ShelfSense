<?php
namespace App\Core;

use App\Core\Database;

class Auth
{
    public static function login($email, $password)
    {
        $db = Database::getInstance()->getConnection();

        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // ✅ Must use password_verify()
        if (!$user || !password_verify($password, $user['password'])) {
            return false;
        }

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['employee_number'] = $user['employee_number'];
        $_SESSION['fullname'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['first_name'] = $user['first_name'];
        $_SESSION['last_name'] = $user['last_name'];
        $_SESSION['is_first_login'] = $user['is_first_login'];

        session_regenerate_id(true);

        return [
            'user_id' => $user['user_id'],
            'role' => $user['role'],
            'employee_number' => $user['employee_number'],
            'fullname' => $user['first_name'] . ' ' . $user['last_name'],
            'is_first_login' => $user['is_first_login']
        ];
    }

    public static function logout()
    {
        $_SESSION = array();

        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        session_destroy();
    }

    public static function check()
    {
        return isset($_SESSION['user_id']);
    }

    public static function user()
    {
        if (!self::check()) {
            return null;
        }

        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE user_id = ? AND is_active = 1");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }

    public static function role()
    {
        return $_SESSION['role'] ?? null;
    }

    public static function userId()
    {
        return $_SESSION['user_id'] ?? null;
    }

    public static function isHR()
    {
        $role = self::role();
        return in_array($role, ['hr_head', 'hr_staff']);
    }

    public static function isHRHead()
    {
        return self::role() === 'hr_head';
    }

    public static function isCashier()
    {
        return self::role() === 'cashier';
    }

    public static function isOwner()
    {
        return self::role() === 'owner';
    }

    public static function isTrainee()
    {
        return self::role() === 'trainee';
    }

    public static function isFirstLogin()
    {
        return isset($_SESSION['is_first_login']) && $_SESSION['is_first_login'] == 1;
    }
}