// ============================================
// SHELFSENSE - GLOBAL FUNCTIONS
// ============================================

console.log('✅ ShelfSense app.js loaded');

// ============================================
// DARK MODE - PERSISTENT & GLOBAL
// ============================================

(function() {
    const htmlElement = document.documentElement;
    
    // Get saved theme from localStorage, or use system preference
    const savedTheme = localStorage.getItem('theme') || 
        (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    
    // Apply theme
    htmlElement.setAttribute('data-bs-theme', savedTheme);
    
    // Function to update all theme toggle icons on the page
    function updateAllThemeIcons(theme) {
        // Update all theme toggle icons (landing, HR, auth, etc.)
        document.querySelectorAll('.theme-toggle-btn, .theme-toggle-btn-auth').forEach(btn => {
            const icon = btn.querySelector('i');
            if (icon) {
                if (theme === 'dark') {
                    icon.classList.remove('bi-moon-stars-fill');
                    icon.classList.add('bi-sun-fill');
                } else {
                    icon.classList.remove('bi-sun-fill');
                    icon.classList.add('bi-moon-stars-fill');
                }
            }
        });
        
        // Also update any standalone theme icons
        document.querySelectorAll('#themeIcon, #themeIconAuth').forEach(icon => {
            if (theme === 'dark') {
                icon.classList.remove('bi-moon-stars-fill');
                icon.classList.add('bi-sun-fill');
            } else {
                icon.classList.remove('bi-sun-fill');
                icon.classList.add('bi-moon-stars-fill');
            }
        });
    }
    
    // Function to toggle theme
    function toggleTheme() {
        const currentTheme = htmlElement.getAttribute('data-bs-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        // Apply theme
        htmlElement.setAttribute('data-bs-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        
        // Update all icons
        updateAllThemeIcons(newTheme);
    }
    
    // Update icons on page load
    updateAllThemeIcons(savedTheme);
    
    // Attach event listeners to all theme toggle buttons
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.theme-toggle-btn, .theme-toggle-btn-auth, #themeToggle, #themeToggleAuth').forEach(btn => {
            btn.addEventListener('click', toggleTheme);
        });
    });
    
    // If DOM already loaded, attach now
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.theme-toggle-btn, .theme-toggle-btn-auth, #themeToggle, #themeToggleAuth').forEach(btn => {
                btn.addEventListener('click', toggleTheme);
            });
        });
    } else {
        document.querySelectorAll('.theme-toggle-btn, .theme-toggle-btn-auth, #themeToggle, #themeToggleAuth').forEach(btn => {
            btn.addEventListener('click', toggleTheme);
        });
    }
    
    // Also listen for system theme changes (optional)
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        if (!localStorage.getItem('theme')) {
            const newTheme = e.matches ? 'dark' : 'light';
            htmlElement.setAttribute('data-bs-theme', newTheme);
            updateAllThemeIcons(newTheme);
        }
    });
    
    // Expose toggle function globally (for inline onclick use)
    window.toggleTheme = toggleTheme;
})();

// ============================================
// GLOBAL: Update Pending Badge
// ============================================

function updatePendingBadge() {
    const badge = document.getElementById('pendingBadge');
    if (!badge) return; // badge not on this page

    fetch('?page=api_get_applicants&p=1&status=all&role=all&search=')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const pending = data.data.stats?.pending || 0;
                if (pending > 0) {
                    badge.textContent = pending;
                    badge.style.display = 'inline-block';
                } else {
                    badge.style.display = 'none';
                }
            }
        })
        .catch(() => {});
}

// ============================================
// DATE VALIDATION
// ============================================

function validateScheduleDate(dateStr) {
    const selected = new Date(dateStr);
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const maxDate = new Date(now);
    maxDate.setMonth(maxDate.getMonth() + 3);

    if (selected < tomorrow) {
        Swal.fire({ icon: 'warning', title: 'Invalid Date', text: 'Please select a date from tomorrow onwards.' });
        return false;
    }
    if (selected > maxDate) {
        Swal.fire({ icon: 'warning', title: 'Invalid Date', text: 'Date cannot exceed 3 months from now.' });
        return false;
    }
    return true;
}

// ============================================
// ON PAGE LOAD – Update Badge
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    updatePendingBadge();
});