<?php
// Enable error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();

// ============================================
// AUTOLOADER - MUST BE FIRST
// ============================================
spl_autoload_register(function ($class) {
    // Core classes: App\Core\Database, App\Core\Auth, etc.
    if (strpos($class, 'App\\Core\\') === 0) {
        $file = __DIR__ . '/../app/core/' . substr($class, 9) . '.php';
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    
    // Model classes: App\Models\Applicant, App\Models\Interview, etc.
    if (strpos($class, 'App\\Models\\') === 0) {
        $file = __DIR__ . '/../app/models/' . substr($class, 10) . '.php';
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    
    // Handler classes: App\Handlers\*, etc.
    if (strpos($class, 'App\\Handlers\\') === 0) {
        $file = __DIR__ . '/../app/handlers/' . substr($class, 12) . '.php';
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

// Load environment variables
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
        }
    }
}

// Load helpers
require_once __DIR__ . '/../app/helpers/functions.php';

// Load core classes (in case autoloader fails)
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Auth.php';
require_once __DIR__ . '/../app/core/Response.php';

use App\Core\Auth;
use App\Core\Response;

// Get the 'page' parameter from URL
$page = isset($_GET['page']) ? $_GET['page'] : 'home';  

// ============================================
// ROUTE: LOGOUT (Always runs first)
// ============================================

if ($page === 'logout') {
    Auth::logout();
    Response::redirect('?page=home');
    exit;
}

// ============================================
// ROUTE: DASHBOARD (Redirect based on role)
// ============================================

if ($page === 'dashboard') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    
    $role = Auth::role();
    switch ($role) {
        case 'owner':
        case 'hr_head':
        case 'hr_staff':
            Response::redirect('?page=hr_dashboard');
            break;
        case 'cashier':
            Response::redirect('?page=pos');
            break;
        case 'trainee':
            Response::redirect('?page=trainee_dashboard');
            break;
        default:
            Response::redirect('?page=home');
    }
    exit;
}

// ============================================
// API ROUTES (MUST come before HTML routes)
// ============================================

if ($page === 'api_login') {
    require_once __DIR__ . '/../app/handlers/api_login.php';
    exit;
}

if ($page === 'api_apply') {
    require_once __DIR__ . '/../app/handlers/api_apply.php';
    exit;
}

// HR API Handlers
if ($page === 'api_get_applicants') {
    require_once __DIR__ . '/../app/handlers/hr/get_applicants.php';
    exit;
}

if ($page === 'api_get_applicant') {
    require_once __DIR__ . '/../app/handlers/hr/get_applicant.php';
    exit;
}

if ($page === 'api_update_status') {
    require_once __DIR__ . '/../app/handlers/hr/update_status.php';
    exit;
}

if ($page === 'api_schedule_interview') {
    require_once __DIR__ . '/../app/handlers/hr/schedule_interview.php';
    exit;
}

if ($page === 'api_get_dashboard_stats') {
    require_once __DIR__ . '/../app/handlers/hr/get_dashboard_stats.php';
    exit;
}

if ($page === 'api_get_trainers_by_role') {
    require_once __DIR__ . '/../app/handlers/hr/get_trainers_by_role.php';
    exit;
}

if ($page === 'api_create_trainee_with_trainer') {
    require_once __DIR__ . '/../app/handlers/hr/create_trainee_with_trainer.php';
    exit;
}

// ============================================
// HR PAGE ROUTES (Require authentication)
// ============================================

if ($page === 'hr_dashboard') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    if (!Auth::isHR() && !Auth::isOwner()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/hr/dashboard.php';
    exit;
}

if ($page === 'hr_applicants') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    if (!Auth::isHR() && !Auth::isOwner()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/hr/applicants.php';
    exit;
}

// ============================================
// PUBLIC HTML ROUTES
// ============================================

// Home / Landing Page
if ($page === 'home' || $page === '') {
    require_once __DIR__ . '/../views/pages/landing.php';
    exit;
}

// Login Page
if ($page === 'login') {
    if (Auth::check()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/auth/login.php';
    exit;
}

// Apply Page
if ($page === 'apply') {
    require_once __DIR__ . '/../views/pages/auth/apply.php';
    exit;
}

// Test Pages (Development only)
if ($page === 'test') {
    require_once __DIR__ . '/../public/test.php';
    exit;
}

if ($page === 'debug_api') {
    require_once __DIR__ . '/../public/debug_api.php';
    exit;
}

// Interviews Routes
if ($page === 'hr_interviews') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    if (!Auth::isHR() && !Auth::isOwner()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/hr/interviews.php';
    exit;
}

if ($page === 'api_get_interviews') {
    require_once __DIR__ . '/../app/handlers/hr/get_interviews.php';
    exit;
}

if ($page === 'api_update_interview') {
    require_once __DIR__ . '/../app/handlers/hr/update_interview.php';
    exit;
}

// Trainees Routes
if ($page === 'hr_trainees') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    if (!Auth::isHR() && !Auth::isOwner()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/hr/trainees.php';
    exit;
}

if ($page === 'api_get_trainees') {
    require_once __DIR__ . '/../app/handlers/hr/get_trainees.php';
    exit;
}

if ($page === 'api_update_trainee') {
    require_once __DIR__ . '/../app/handlers/hr/update_trainee.php';
    exit;
}

// Trainer Routes
if ($page === 'api_get_trainers_by_role') {
    require_once __DIR__ . '/../app/handlers/hr/get_trainers_by_role.php';
    exit;
}

if ($page === 'api_create_trainee_with_trainer') {
    require_once __DIR__ . '/../app/handlers/hr/create_trainee_with_trainer.php';
    exit;
}

if ($page === 'api_create_contract_from_interview') {
    require_once __DIR__ . '/../app/handlers/hr/create_contract_from_interview.php';
    exit;
}

if ($page === 'api_update_contract') {
    require_once __DIR__ . '/../app/handlers/hr/update_contract.php';
    exit;
}

// Contracts Routes
if ($page === 'hr_contracts') {
    if (!Auth::check()) {
        Response::redirect('?page=login');
        exit;
    }
    if (!Auth::isHR() && !Auth::isOwner()) {
        Response::redirect('?page=dashboard');
        exit;
    }
    require_once __DIR__ . '/../views/pages/hr/contracts.php';
    exit;
}

if ($page === 'api_get_contracts') {
    require_once __DIR__ . '/../app/handlers/hr/get_contracts.php';
    exit;
}

if ($page === 'api_create_contract') {
    require_once __DIR__ . '/../app/handlers/hr/create_contract.php';
    exit;
}

if ($page === 'api_update_contract') {
    require_once __DIR__ . '/../app/handlers/hr/update_contract.php';
    exit;
}

// Report Routes
if ($page === 'api_submit_report') {
    require_once __DIR__ . '/../app/handlers/hr/submit_report.php';
    exit;
}

if ($page === 'api_review_reports') {
    require_once __DIR__ . '/../app/handlers/hr/review_reports.php';
    exit;
}

// ============================================
// 404 - Page Not Found (MUST be last)
// ============================================

http_response_code(404);
echo "<h1>404 - Page Not Found</h1>";
echo "<p>Page: " . htmlspecialchars($page) . "</p>";
echo "<p><a href='?page=home'>Go Home</a></p>";
exit;