-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2026 at 07:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shelfsense`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `target_role` varchar(50) NOT NULL COMMENT 'Cashier, HR, Finance, etc.',
  `resume_path` varchar(255) NOT NULL,
  `status` enum('pending','initial_scheduled','initial_passed','initial_failed','final_scheduled','final_passed','final_failed','screening','screening_success','screening_failed','contract_offered','contract_declined','hired') DEFAULT 'pending',
  `applied_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `first_name`, `last_name`, `middle_name`, `email`, `phone`, `target_role`, `resume_path`, `status`, `applied_date`, `updated_at`) VALUES
(1, 'John', 'Doe', NULL, 'john.doe@test.com', '09123456789', 'Cashier', 'uploads/resumes/test_resume1.pdf', 'hired', '2026-08-15 10:48:35', '2026-08-16 06:44:15'),
(2, 'Jane', 'Smith', NULL, 'jane.smith@test.com', '09123456780', 'HR Staff', 'uploads/resumes/test_resume2.pdf', 'hired', '2026-08-15 10:48:35', '2026-08-16 11:47:28'),
(3, 'Mark', 'Johnson', NULL, 'mark.johnson@test.com', '09123456781', 'Finance Staff', 'uploads/resumes/test_resume3.pdf', 'final_passed', '2026-08-15 10:48:35', '2026-08-16 11:06:20'),
(4, 'Sarah', 'Williams', NULL, 'sarah.williams@test.com', '09123456782', 'Head HR', 'uploads/resumes/test_resume4.pdf', 'initial_passed', '2026-08-15 10:48:35', '2026-08-16 11:00:38'),
(5, 'David', 'Brown', NULL, 'david.brown@test.com', '09123456783', 'Cashier', 'uploads/resumes/test_resume5.pdf', 'initial_passed', '2026-08-15 10:48:35', '2026-08-16 11:01:40'),
(6, 'Emily', 'Davis', NULL, 'emily.davis@test.com', '09123456784', 'Finance Staff', 'uploads/resumes/test_resume6.pdf', 'pending', '2026-08-15 10:48:35', '2026-08-16 04:35:41'),
(7, 'Michael', 'Wilson', NULL, 'michael.wilson@test.com', '09123456785', 'HR Staff', 'uploads/resumes/test_resume7.pdf', 'pending', '2026-08-15 10:48:35', '2026-08-16 04:35:41'),
(8, 'Jessica', 'Taylor', NULL, 'jessica.taylor@test.com', '09123456786', 'Head Finance', 'uploads/resumes/test_resume8.pdf', 'pending', '2026-08-15 10:48:35', '2026-08-16 04:35:41'),
(9, 'Daniel', 'Anderson', NULL, 'daniel.anderson@test.com', '09123456787', 'Cashier', 'uploads/resumes/test_resume9.pdf', 'pending', '2026-08-15 10:48:35', '2026-08-16 04:35:41'),
(10, 'Lisa', 'Martinez', NULL, 'lisa.martinez@test.com', '09123456788', 'HR Staff', 'uploads/resumes/test_resume10.pdf', 'pending', '2026-08-15 10:48:35', '2026-08-16 04:35:41'),
(11, 'test', 'test', 'test', 'test@emai.com', '09264550078', 'Cashier', 'C:\\xampp\\htdocs\\ShelfSense\\app\\handlers/../../public/uploads/resumes//1786881276_Final_Activity_in_Ethics_Kindness_in_Action.docx', 'pending', '2026-08-16 11:54:36', '2026-08-16 11:54:36'),
(12, 'test', 'test', 'test', 'test@emaikl.ciom', '09264550078', 'Cashier', 'C:\\xampp\\htdocs\\ShelfSense\\app\\handlers/../../public/uploads/resumes//1786881825_IT204-MIDTERM-WEEK4.pdf', 'pending', '2026-08-16 12:03:45', '2026-08-16 12:03:45'),
(13, 'testing', 'testing', 'test', 'testing@emaial.com', '09264250078', 'HR Staff', 'C:\\xampp\\htdocs\\ShelfSense\\app\\handlers/../../public/uploads/resumes//1786927381_Final_Activity_in_Ethics_Kindness_in_Action.docx', 'pending', '2026-08-17 00:43:02', '2026-08-17 00:43:02');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('present','absent','late','on_leave') DEFAULT 'present',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shift` enum('opening','closing','midshift') NOT NULL,
  `salary` decimal(10,2) NOT NULL,
  `job_details` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `status` enum('pending','accepted','declined') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `salary_range_min` decimal(10,2) DEFAULT NULL,
  `salary_range_max` decimal(10,2) DEFAULT NULL,
  `decision_deadline` date DEFAULT NULL,
  `offered_by` int(11) DEFAULT NULL,
  `offered_at` timestamp NULL DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `declined_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contracts`
--

INSERT INTO `contracts` (`id`, `applicant_id`, `user_id`, `shift`, `salary`, `job_details`, `start_date`, `status`, `created_at`, `updated_at`, `salary_range_min`, `salary_range_max`, `decision_deadline`, `offered_by`, `offered_at`, `accepted_at`, `declined_at`) VALUES
(1, 1, 7, 'opening', 0.00, NULL, '0000-00-00', 'accepted', '2026-08-16 06:42:37', '2026-08-16 06:44:15', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, 8, 'opening', 13800.00, '', '2026-08-17', 'accepted', '2026-08-16 11:46:23', '2026-08-16 11:47:28', NULL, NULL, '2026-08-21', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `email_logs`
--

CREATE TABLE `email_logs` (
  `id` int(11) NOT NULL,
  `recipient_email` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `status` enum('sent','failed') DEFAULT 'sent',
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `interviews`
--

CREATE TABLE `interviews` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `hr_user_id` int(11) NOT NULL,
  `interview_type` enum('initial','final','contract') NOT NULL,
  `scheduled_date` datetime NOT NULL,
  `gmeet_link` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled') DEFAULT 'scheduled',
  `result` enum('passed','failed','pending') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interviews`
--

INSERT INTO `interviews` (`id`, `applicant_id`, `hr_user_id`, `interview_type`, `scheduled_date`, `gmeet_link`, `message`, `notes`, `status`, `result`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'initial', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', '', '', 'completed', 'passed', '2026-08-16 04:35:50', '2026-08-16 04:44:36'),
(2, 2, 1, 'initial', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', 's', '', 'completed', 'passed', '2026-08-16 04:44:23', '2026-08-16 04:51:18'),
(3, 3, 1, 'initial', '2026-08-17 02:00:00', '', '', '', 'completed', 'passed', '2026-08-16 04:58:26', '2026-08-16 05:01:18'),
(4, 1, 2, 'final', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', 'asdasd', '', 'completed', 'passed', '2026-08-16 06:35:50', '2026-08-16 06:37:44'),
(5, 1, 2, 'contract', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', 'testing', NULL, 'completed', 'pending', '2026-08-16 06:39:36', '2026-08-16 06:42:37'),
(6, 4, 2, 'initial', '2026-08-17 12:00:00', 'https://meet.google.com/xxx-xxx-xxx', '', '', 'completed', 'passed', '2026-08-16 11:00:20', '2026-08-16 11:00:38'),
(7, 2, 2, 'final', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', '', '', 'completed', 'passed', '2026-08-16 11:01:01', '2026-08-16 11:01:11'),
(8, 5, 2, 'initial', '2026-08-17 02:00:00', 'https://meet.google.com/xxx-xxx-xxx', '', '', 'completed', 'passed', '2026-08-16 11:01:32', '2026-08-16 11:01:40'),
(9, 3, 2, 'final', '2026-08-17 19:01:00', 'https://meet.google.com/xxx-xxx-xxx', '', '', 'completed', 'passed', '2026-08-16 11:02:04', '2026-08-16 11:06:20'),
(10, 2, 1, 'contract', '2026-08-17 19:46:00', 'https://meet.google.com/xxx-xxx-xxx', '', NULL, 'completed', 'passed', '2026-08-16 11:46:13', '2026-08-16 11:46:24');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `leave_type` enum('sick','vacation','emergency','other') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_balances`
--

CREATE TABLE `leave_balances` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `total_days` decimal(5,2) DEFAULT 5.00,
  `used_days` decimal(5,2) DEFAULT 0.00,
  `remaining_days` decimal(5,2) GENERATED ALWAYS AS (`total_days` - `used_days`) STORED,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `message`, `link`, `is_read`, `created_at`) VALUES
(1, 1, 'interview_scheduled', 'initial interview scheduled for John Doe', NULL, 0, '2026-08-15 18:06:10'),
(2, 1, 'interview_scheduled', 'initial interview scheduled for Jane Smith', NULL, 0, '2026-08-15 18:17:52'),
(3, 3, 'status_update', 'Applicant John Doe moved to: Final scheduled', NULL, 0, '2026-08-15 18:34:41'),
(4, 3, 'interview_scheduled', 'final interview scheduled for Jane Smith', NULL, 0, '2026-08-15 19:03:29'),
(5, 3, 'status_update', 'Applicant John Doe moved to: Initial scheduled', NULL, 0, '2026-08-15 19:06:36'),
(6, 3, 'interview_scheduled', 'initial interview scheduled for Jane Smith', NULL, 0, '2026-08-15 19:12:08'),
(7, 1, 'interview_scheduled', 'final interview scheduled for Jane Smith', NULL, 0, '2026-08-15 19:15:25'),
(8, 1, 'interview_scheduled', 'initial interview scheduled for John Doe', NULL, 0, '2026-08-15 19:19:47'),
(9, 2, 'interview_scheduled', 'final interview updated for John Doe', NULL, 0, '2026-08-15 19:20:57'),
(10, 2, 'trainee_created', 'Trainee account created for John Doe with trainer', NULL, 0, '2026-08-16 01:55:43'),
(11, 2, 'trainee_created', 'Trainee account created for John Doe', NULL, 0, '2026-08-16 02:00:14'),
(12, 2, 'trainee_created', 'Trainee account created for John Doe', NULL, 0, '2026-08-16 02:11:15'),
(13, 2, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 02:15:26'),
(14, 2, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 02:15:29'),
(15, 2, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 02:15:33'),
(16, 2, 'reports_reviewed', 'Trainee reviewed: eligible', NULL, 0, '2026-08-16 02:15:38'),
(17, 2, 'interview_scheduled', 'contract interview scheduled for John Doe', NULL, 0, '2026-08-16 02:15:47'),
(18, 2, 'interview_scheduled', 'contract interview scheduled for John Doe', NULL, 0, '2026-08-16 02:22:50'),
(19, 1, 'interview_scheduled', 'contract interview scheduled for John Doe', NULL, 0, '2026-08-16 02:38:31'),
(20, 1, 'contract_update_details', 'Contract update_detailsed for 1', NULL, 0, '2026-08-16 03:38:29'),
(21, 1, 'contract_accept', 'Contract accepted for 1', NULL, 0, '2026-08-16 03:38:50'),
(22, 1, 'interview_scheduled', 'initial interview scheduled for John Doe', NULL, 0, '2026-08-16 04:35:51'),
(23, 1, 'interview_scheduled', 'initial interview scheduled for Jane Smith', NULL, 0, '2026-08-16 04:44:24'),
(24, 1, 'interview_scheduled', 'initial interview scheduled for Mark Johnson', NULL, 0, '2026-08-16 04:58:26'),
(25, 2, 'interview_scheduled', 'final interview updated for John Doe', NULL, 0, '2026-08-16 06:35:52'),
(26, 2, 'trainee_created', 'Trainee account created for John Doe', NULL, 0, '2026-08-16 06:38:41'),
(27, 2, 'report_submitted', 'Report submitted for trainee ID: 1', NULL, 0, '2026-08-16 06:38:58'),
(28, 2, 'report_submitted', 'Report submitted for trainee ID: 1', NULL, 0, '2026-08-16 06:39:02'),
(29, 2, 'report_submitted', 'Report submitted for trainee ID: 1', NULL, 0, '2026-08-16 06:39:07'),
(30, 2, 'reports_reviewed', 'Trainee reviewed: eligible', NULL, 0, '2026-08-16 06:39:13'),
(31, 2, 'interview_scheduled', 'contract interview scheduled for John Doe', NULL, 0, '2026-08-16 06:39:36'),
(32, 2, 'contract_accept', 'Contract accepted for 1', NULL, 0, '2026-08-16 06:44:16'),
(33, 2, 'interview_scheduled', 'initial interview scheduled for Sarah Williams', NULL, 0, '2026-08-16 11:00:20'),
(34, 2, 'interview_scheduled', 'final interview updated for Jane Smith', NULL, 0, '2026-08-16 11:01:02'),
(35, 2, 'interview_scheduled', 'initial interview scheduled for David Brown', NULL, 0, '2026-08-16 11:01:32'),
(36, 2, 'interview_scheduled', 'final interview updated for Mark Johnson', NULL, 0, '2026-08-16 11:02:04'),
(37, 1, 'trainee_created', 'Trainee account created for Jane Smith. Trainer Ana Reyes is locked.', NULL, 0, '2026-08-16 11:44:09'),
(38, 1, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 11:45:26'),
(39, 1, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 11:45:30'),
(40, 1, 'report_submitted', 'Report submitted for trainee ID: 2', NULL, 0, '2026-08-16 11:45:34'),
(41, 1, 'reports_reviewed', 'Trainee reviewed: eligible. Trainer released.', NULL, 0, '2026-08-16 11:45:42'),
(42, 1, 'interview_scheduled', 'contract interview scheduled for Jane Smith', NULL, 0, '2026-08-16 11:46:13'),
(43, 1, 'contract_update_details', 'Contract update_detailsed for employee ID: 8', NULL, 0, '2026-08-16 11:47:13'),
(44, 1, 'contract_accept', 'Contract accepted for employee ID: 8', NULL, 0, '2026-08-16 11:47:28'),
(45, 1, 'new_application', 'New application from test test for Cashier position', '?page=hr_applicants', 0, '2026-08-16 12:03:45'),
(46, 2, 'new_application', 'New application from test test for Cashier position', '?page=hr_applicants', 0, '2026-08-16 12:03:45'),
(47, 3, 'new_application', 'New application from test test for Cashier position', '?page=hr_applicants', 0, '2026-08-16 12:03:46'),
(48, 4, 'new_application', 'New application from test test for Cashier position', '?page=hr_applicants', 0, '2026-08-16 12:03:46'),
(49, 8, 'new_application', 'New application from test test for Cashier position', '?page=hr_applicants', 0, '2026-08-16 12:03:46'),
(50, 1, 'new_application', 'New application from testing testing for HR Staff position', '?page=hr_applicants', 0, '2026-08-17 00:43:04'),
(51, 2, 'new_application', 'New application from testing testing for HR Staff position', '?page=hr_applicants', 0, '2026-08-17 00:43:04'),
(52, 3, 'new_application', 'New application from testing testing for HR Staff position', '?page=hr_applicants', 0, '2026-08-17 00:43:04'),
(53, 4, 'new_application', 'New application from testing testing for HR Staff position', '?page=hr_applicants', 0, '2026-08-17 00:43:04'),
(54, 8, 'new_application', 'New application from testing testing for HR Staff position', '?page=hr_applicants', 0, '2026-08-17 00:43:04');

-- --------------------------------------------------------

--
-- Table structure for table `rejection_reasons`
--

CREATE TABLE `rejection_reasons` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `hr_user_id` int(11) NOT NULL,
  `stage` enum('initial','final','screening','contract') NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trainees`
--

CREATE TABLE `trainees` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `target_role` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `schedule_start` time DEFAULT '10:00:00',
  `schedule_end` time DEFAULT '15:00:00',
  `status` enum('active','completed','terminated') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trainee_salary_min` decimal(10,2) DEFAULT 3900.00,
  `trainee_salary_max` decimal(10,2) DEFAULT 4500.00,
  `trainee_salary_set_at` timestamp NULL DEFAULT NULL,
  `report_1` text DEFAULT NULL COMMENT 'Month 1 report',
  `report_2` text DEFAULT NULL COMMENT 'Month 2 report',
  `report_3` text DEFAULT NULL COMMENT 'Month 3 report',
  `reports_status` enum('pending','reviewed','completed') DEFAULT 'pending',
  `eligible_for_contract` tinyint(1) DEFAULT 0,
  `decision_deadline` date DEFAULT NULL,
  `contract_offered_date` date DEFAULT NULL,
  `trainer_released_at` datetime DEFAULT NULL,
  `training_completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainees`
--

INSERT INTO `trainees` (`id`, `applicant_id`, `user_id`, `trainer_id`, `target_role`, `start_date`, `end_date`, `schedule_start`, `schedule_end`, `status`, `created_at`, `updated_at`, `trainee_salary_min`, `trainee_salary_max`, `trainee_salary_set_at`, `report_1`, `report_2`, `report_3`, `reports_status`, `eligible_for_contract`, `decision_deadline`, `contract_offered_date`, `trainer_released_at`, `training_completed_at`) VALUES
(1, 1, 7, 5, 'Cashier', '2026-08-16', '2026-11-16', '10:00:00', '15:00:00', 'active', '2026-08-16 06:38:41', '2026-08-16 06:42:37', 3900.00, 4500.00, NULL, 'testing reports', 'testing reports', 'testing reports', 'reviewed', 1, NULL, NULL, NULL, NULL),
(2, 2, 8, 3, 'HR Staff', '2026-08-16', '2026-11-16', '10:00:00', '15:00:00', 'completed', '2026-08-16 11:44:09', '2026-08-16 11:46:24', 3900.00, 4500.00, NULL, 'testtest123', 'testtest123', 'testtest123', 'reviewed', 1, NULL, NULL, '2026-08-16 19:45:41', '2026-08-16 19:45:41');

-- --------------------------------------------------------

--
-- Table structure for table `trainee_reports`
--

CREATE TABLE `trainee_reports` (
  `id` int(11) NOT NULL,
  `trainee_id` int(11) NOT NULL,
  `report_date` date NOT NULL,
  `attendance_notes` text DEFAULT NULL,
  `mishaps` text DEFAULT NULL,
  `performance_notes` text DEFAULT NULL,
  `submitted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `employee_number` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('owner','hr_head','hr_staff','cashier','finance_head','finance_staff','trainee') NOT NULL,
  `can_train` tinyint(1) DEFAULT 0,
  `is_supervising` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `is_first_login` tinyint(1) DEFAULT 1,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `hired_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `employee_number`, `first_name`, `last_name`, `middle_name`, `email`, `password`, `role`, `can_train`, `is_supervising`, `is_active`, `is_first_login`, `profile_pic`, `created_at`, `updated_at`, `hired_date`) VALUES
(1, 'HH-001', 'Maria', 'Santos', NULL, 'maria.santos@shelfsense.com', '$2y$10$JNrnPP.TfsAws1o1AwAYJ.Gim25c6QgPhyQFcMJOJLHAtUE3NyHTu', 'hr_head', 1, 1, 1, 1, NULL, '2026-08-15 18:01:47', '2026-08-15 18:05:55', NULL),
(2, 'HS-001', 'Juan', 'Dela Cruz', NULL, 'juan.delacruz@shelfsense.com', '$2y$10$JNrnPP.TfsAws1o1AwAYJ.Gim25c6QgPhyQFcMJOJLHAtUE3NyHTu', 'hr_staff', 1, 0, 1, 1, NULL, '2026-08-15 18:01:47', '2026-08-15 18:05:55', NULL),
(3, 'HS-002', 'Ana', 'Reyes', NULL, 'ana.reyes@shelfsense.com', '$2y$10$JNrnPP.TfsAws1o1AwAYJ.Gim25c6QgPhyQFcMJOJLHAtUE3NyHTu', 'hr_staff', 1, 0, 1, 1, NULL, '2026-08-15 18:01:47', '2026-08-16 11:45:41', NULL),
(4, 'HS-003', 'Pedro', 'Cruz', NULL, 'pedro.cruz@shelfsense.com', '$2y$10$JNrnPP.TfsAws1o1AwAYJ.Gim25c6QgPhyQFcMJOJLHAtUE3NyHTu', 'hr_staff', 1, 0, 1, 1, NULL, '2026-08-15 18:01:47', '2026-08-16 01:51:49', NULL),
(5, 'CA-001', 'Cashier', 'Test', NULL, 'cashier@shelfsense.com', '$2y$10$JNrnPP.TfsAws1o1AwAYJ.Gim25c6QgPhyQFcMJOJLHAtUE3NyHTu', 'cashier', 1, 0, 1, 1, NULL, '2026-08-15 18:01:47', '2026-08-16 01:51:49', NULL),
(7, 'CA-591', 'John', 'Doe', '', 'john.doe@test.com', '$2y$10$hxOPSl0Lz5zAwEWjObcobu.BgMZHGSieljfjsMis32e0dB2QeyRg6', 'cashier', 1, 0, 1, 1, NULL, '2026-08-16 02:11:14', '2026-08-16 06:44:15', '2026-08-16 06:44:15'),
(8, 'HS-225', 'Jane', 'Smith', '', 'jane.smith@test.com', '$2y$10$f6bxdSX84ZWs2mXpNVKIKuX4vdMYPZl3acU9EnLt0/8o0AAwZiYOC', 'hr_staff', 1, 0, 1, 1, NULL, '2026-08-16 11:44:09', '2026-08-16 11:47:28', '2026-08-16 11:47:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_target_role` (`target_role`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_id`,`date`),
  ADD KEY `idx_date` (`date`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_contract_user` (`user_id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `offered_by` (`offered_by`);

--
-- Indexes for table `email_logs`
--
ALTER TABLE `email_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_recipient` (`recipient_email`);

--
-- Indexes for table `interviews`
--
ALTER TABLE `interviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_applicant` (`applicant_id`),
  ADD KEY `idx_hr` (`hr_user_id`),
  ADD KEY `idx_type` (`interview_type`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approved_by` (`approved_by`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_year` (`user_id`,`year`),
  ADD KEY `idx_year` (`year`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_read` (`user_id`,`is_read`);

--
-- Indexes for table `rejection_reasons`
--
ALTER TABLE `rejection_reasons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `hr_user_id` (`hr_user_id`);

--
-- Indexes for table `trainees`
--
ALTER TABLE `trainees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_trainee_user` (`user_id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `trainer_id` (`trainer_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_target_role` (`target_role`);

--
-- Indexes for table `trainee_reports`
--
ALTER TABLE `trainee_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `submitted_by` (`submitted_by`),
  ADD KEY `idx_trainee` (`trainee_id`),
  ADD KEY `idx_report_date` (`report_date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `employee_number` (`employee_number`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_employee_number` (`employee_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `email_logs`
--
ALTER TABLE `email_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `interviews`
--
ALTER TABLE `interviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_balances`
--
ALTER TABLE `leave_balances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `rejection_reasons`
--
ALTER TABLE `rejection_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trainees`
--
ALTER TABLE `trainees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trainee_reports`
--
ALTER TABLE `trainee_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `contracts`
--
ALTER TABLE `contracts`
  ADD CONSTRAINT `contracts_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contracts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `contracts_ibfk_3` FOREIGN KEY (`offered_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `interviews`
--
ALTER TABLE `interviews`
  ADD CONSTRAINT `interviews_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `interviews_ibfk_2` FOREIGN KEY (`hr_user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `leaves_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD CONSTRAINT `leave_balances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `rejection_reasons`
--
ALTER TABLE `rejection_reasons`
  ADD CONSTRAINT `rejection_reasons_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rejection_reasons_ibfk_2` FOREIGN KEY (`hr_user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `trainees`
--
ALTER TABLE `trainees`
  ADD CONSTRAINT `trainees_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `trainees_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `trainees_ibfk_3` FOREIGN KEY (`trainer_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `trainee_reports`
--
ALTER TABLE `trainee_reports`
  ADD CONSTRAINT `trainee_reports_ibfk_1` FOREIGN KEY (`trainee_id`) REFERENCES `trainees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `trainee_reports_ibfk_2` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
